# Carbone Office Add-in 安装说明

## 文件列表
- manifest-word.xml - Word加载项配置文件
- ca.crt - SSL CA证书

## 安装步骤

### 1. 安装CA证书（必须）
双击 `ca.crt` 文件，或使用命令：
```powershell
certutil -addstore -f "Root" ca.crt
```

### 2. 配置受信任加载项目录
创建目录并注册：
```powershell
mkdir C:\OfficeAddins
reg add HKCU\SOFTWARE\Microsoft\Office\16.0\Wef /v DevelopmentLocation /t REG_SZ /d "C:\OfficeAddins" /f
```

### 3. 复制manifest文件
将 `manifest-word.xml` 复制到 `C:\OfficeAddins\`

### 4. 重启Word
关闭所有Word窗口后重新打开

### 5. 查看加载项
- 插入 → 我的加载项 → 共享文件夹
- 或查看右侧任务窗格

## 服务地址
- Add-in: https://192.168.100.143:3000/taskpane.html
- API: http://192.168.100.143:3100

## 测试网络连接
在浏览器中访问：https://192.168.100.143:3000/health
应返回：{"status":"ok",...}