# Carbone Office Add-in 安装说明

## 文件列表
- manifest-word.xml - Word加载项配置文件（已简化，去除VersionOverrides）
- ca.crt - SSL CA证书

## 重要：清除旧的加载项缓存

在安装新manifest之前，必须清除Word缓存：

```powershell
Remove-Item -Recurse -Force "$env:LOCALAPPDATA\Microsoft\Office\16.0\Wef\*"
```

## 安装步骤

### 1. 安装CA证书（必须）
```powershell
certutil -addstore -f "Root" ca.crt
```

### 2. 配置加载项目录
```powershell
mkdir C:\OfficeAddins
copy manifest-word.xml C:\OfficeAddins\
reg add HKCU\SOFTWARE\Microsoft\Office\16.0\Wef /v DevelopmentLocation /t REG_SZ /d "C:\OfficeAddins" /f
```

### 3. 重启Word
完全关闭Word后重新打开

### 4. 查看加载项
插入 → 我的加载项 → 共享文件夹 → Carbone Template Assistant

## 服务地址
- Taskpane: https://192.168.100.143:3000/taskpane.html
- Health: https://192.168.100.143:3000/health

## 测试
在浏览器中访问 https://192.168.100.143:3000/test.html
如果显示 "Host: Word, Platform: PC" 则表示在Word环境中运行正常
